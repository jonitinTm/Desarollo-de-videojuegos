Package: box2d:x64-windows@3.1.1

**Host Environment**

- Host: x64-windows
- Compiler: MSVC 19.51.36260.0
- CMake Version: 4.4.4
-    vcpkg-tool version: 2026-07-27-98d7cb0cf1f4686a3e43aa5672b6230c1d56bce8
    vcpkg-readonly: true
    vcpkg-scripts version: 1460b31b08c42cc2e9ac2c79f45ec8707e2675e2

**To Reproduce**

`vcpkg install `

**Failure logs**

```
Downloading https://github.com/erincatto/Box2D/archive/v3.1.1.tar.gz -> erincatto-Box2D-v3.1.1.tar.gz
Successfully downloaded erincatto-Box2D-v3.1.1.tar.gz
-- Extracting source C:/Users/jonat/AppData/Local/vcpkg/downloads/erincatto-Box2D-v3.1.1.tar.gz
-- Applying patch libm.diff
-- Using source at C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean
-- Configuring x64-windows
CMake Error at scripts/cmake/vcpkg_execute_required_process.cmake:127 (message):
    Command failed: "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\Common7\\IDE\\CommonExtensions\\Microsoft\\CMake\\Ninja\\ninja.exe" -v
    Working Directory: C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/vcpkg-parallel-configure
    Error code: 1
    See logs for more information:
      C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-dbg-CMakeCache.txt.log
      C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-rel-CMakeCache.txt.log
      C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-dbg-CMakeConfigureLog.yaml.log
      C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-rel-CMakeConfigureLog.yaml.log
      C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-out.log

Call Stack (most recent call first):
  C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/share/vcpkg-cmake/vcpkg_cmake_configure.cmake:269 (vcpkg_execute_required_process)
  C:/Users/jonat/AppData/Local/vcpkg/registries/git-trees/81f894b99ba686f428b3d80e7769ee04f8bf548e/portfile.cmake:12 (vcpkg_cmake_configure)
  scripts/ports.cmake:209 (include)



```

<details><summary>C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-out.log</summary>

```
[1/2] "C:/Program Files/CMake/bin/cmake.exe" -E chdir "../../x64-windows-dbg" "C:/Program Files/CMake/bin/cmake.exe" "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean" "-G" "Ninja" "-DCMAKE_BUILD_TYPE=Debug" "-DCMAKE_INSTALL_PREFIX=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/pkgs/box2d_x64-windows/debug" "-DFETCHCONTENT_FULLY_DISCONNECTED=ON" "-DBOX2D_SAMPLES=OFF" "-DBOX2D_BENCHMARKS=OFF" "-DBOX2D_DOCS=OFF" "-DBOX2D_PROFILE=OFF" "-DBOX2D_VALIDATE=OFF" "-DBOX2D_UNIT_TESTS=OFF" "-DBOX2D_COMPILE_WARNING_AS_ERROR=OFF" "-DCMAKE_MAKE_PROGRAM=C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe" "-DBUILD_SHARED_LIBS=ON" "-DVCPKG_CHAINLOAD_TOOLCHAIN_FILE=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake" "-DVCPKG_TARGET_TRIPLET=x64-windows" "-DVCPKG_SET_CHARSET_FLAG=ON" "-DVCPKG_PLATFORM_TOOLSET=v145" "-DCMAKE_EXPORT_NO_PACKAGE_REGISTRY=ON" "-DCMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY=ON" "-DCMAKE_FIND_PACKAGE_NO_SYSTEM_PACKAGE_REGISTRY=ON" "-DCMAKE_INSTALL_SYSTEM_RUNTIME_LIBS_SKIP=TRUE" "-DCMAKE_VERBOSE_MAKEFILE=ON" "-DVCPKG_APPLOCAL_DEPS=OFF" "-DCMAKE_TOOLCHAIN_FILE=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/buildsystems/vcpkg.cmake" "-DCMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION=ON" "-DVCPKG_CXX_FLAGS=" "-DVCPKG_CXX_FLAGS_RELEASE=" "-DVCPKG_CXX_FLAGS_DEBUG=" "-DVCPKG_C_FLAGS=" "-DVCPKG_C_FLAGS_RELEASE=" "-DVCPKG_C_FLAGS_DEBUG=" "-DVCPKG_CRT_LINKAGE=dynamic" "-DVCPKG_LINKER_FLAGS=" "-DVCPKG_LINKER_FLAGS_RELEASE=" "-DVCPKG_LINKER_FLAGS_DEBUG=" "-DVCPKG_TARGET_ARCHITECTURE=x64" "-DCMAKE_INSTALL_LIBDIR:STRING=lib" "-DCMAKE_INSTALL_BINDIR:STRING=bin" "-D_VCPKG_ROOT_DIR=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/" "-D_VCPKG_INSTALLED_DIR=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/" "-DVCPKG_MANIFEST_INSTALL=OFF"
FAILED: [code=1] ../../x64-windows-dbg/CMakeCache.txt 
...
Skipped 64 lines
...
FAILED: [code=1] ../CMakeCache.txt 
"C:/Program Files/CMake/bin/cmake.exe" -E chdir ".." "C:/Program Files/CMake/bin/cmake.exe" "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean" "-G" "Ninja" "-DCMAKE_BUILD_TYPE=Release" "-DCMAKE_INSTALL_PREFIX=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/pkgs/box2d_x64-windows" "-DFETCHCONTENT_FULLY_DISCONNECTED=ON" "-DBOX2D_SAMPLES=OFF" "-DBOX2D_BENCHMARKS=OFF" "-DBOX2D_DOCS=OFF" "-DBOX2D_PROFILE=OFF" "-DBOX2D_VALIDATE=OFF" "-DBOX2D_UNIT_TESTS=OFF" "-DBOX2D_COMPILE_WARNING_AS_ERROR=OFF" "-DCMAKE_MAKE_PROGRAM=C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe" "-DBUILD_SHARED_LIBS=ON" "-DVCPKG_CHAINLOAD_TOOLCHAIN_FILE=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake" "-DVCPKG_TARGET_TRIPLET=x64-windows" "-DVCPKG_SET_CHARSET_FLAG=ON" "-DVCPKG_PLATFORM_TOOLSET=v145" "-DCMAKE_EXPORT_NO_PACKAGE_REGISTRY=ON" "-DCMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY=ON" "-DCMAKE_FIND_PACKAGE_NO_SYSTEM_PACKAGE_REGISTRY=ON" "-DCMAKE_INSTALL_SYSTEM_RUNTIME_LIBS_SKIP=TRUE" "-DCMAKE_VERBOSE_MAKEFILE=ON" "-DVCPKG_APPLOCAL_DEPS=OFF" "-DCMAKE_TOOLCHAIN_FILE=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/buildsystems/vcpkg.cmake" "-DCMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION=ON" "-DVCPKG_CXX_FLAGS=" "-DVCPKG_CXX_FLAGS_RELEASE=" "-DVCPKG_CXX_FLAGS_DEBUG=" "-DVCPKG_C_FLAGS=" "-DVCPKG_C_FLAGS_RELEASE=" "-DVCPKG_C_FLAGS_DEBUG=" "-DVCPKG_CRT_LINKAGE=dynamic" "-DVCPKG_LINKER_FLAGS=" "-DVCPKG_LINKER_FLAGS_RELEASE=" "-DVCPKG_LINKER_FLAGS_DEBUG=" "-DVCPKG_TARGET_ARCHITECTURE=x64" "-DCMAKE_INSTALL_LIBDIR:STRING=lib" "-DCMAKE_INSTALL_BINDIR:STRING=bin" "-D_VCPKG_ROOT_DIR=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/" "-D_VCPKG_INSTALLED_DIR=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/" "-DVCPKG_MANIFEST_INSTALL=OFF"
-- The C compiler identification is MSVC 19.51.36260.0
-- The CXX compiler identification is MSVC 19.51.36260.0
-- Detecting C compiler ABI info
CMake Warning in C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-idc09u/CMakeLists.txt:
  The object file directory

    C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-idc09u/CMakeFiles/cmTC_d5ae3.dir/./

  has 262 characters.  The maximum full path to an object file is 250
  characters (see CMAKE_OBJECT_PATH_MAX).  Object file

    54c0e731.obj

  cannot be safely placed under this directory.  The build may not work
  correctly.


-- Detecting C compiler ABI info - failed
-- Check for working C compiler: C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe
CMake Warning in C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27/CMakeLists.txt:
  The object file directory

    C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27/CMakeFiles/cmTC_2a00d.dir/./

  has 262 characters.  The maximum full path to an object file is 250
  characters (see CMAKE_OBJECT_PATH_MAX).  Object file

    9b49cb7c.obj

  cannot be safely placed under this directory.  The build may not work
  correctly.


-- Check for working C compiler: C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe - broken
CMake Error at C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeTestCCompiler.cmake:65 (message):
  The C compiler

    "C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe"

  is not able to compile a simple test program.

  It fails with the following output:

    Change Dir: 'C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27'
    
    Run Build Command(s): "C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe" -v cmTC_2a00d
    [1/2] "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\cmTC_2a00d.dir\testCCompiler.c.obj /FdCMakeFiles\cmTC_2a00d.dir\ /FS -c C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\x64-windows-rel\CMakeFiles\CMakeScratch\TryCompile-5cmz27\testCCompiler.c
    FAILED: [code=1] CMakeFiles/cmTC_2a00d.dir/testCCompiler.c.obj 
    "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\cmTC_2a00d.dir\testCCompiler.c.obj /FdCMakeFiles\cmTC_2a00d.dir\ /FS -c C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\x64-windows-rel\CMakeFiles\CMakeScratch\TryCompile-5cmz27\testCCompiler.c
    C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\x64-windows-rel\CMakeFiles\CMakeScratch\TryCompile-5cmz27\testCCompiler.c : fatal error C1083: No se puede abrir el archivo generado por el compilador: '': Invalid argument
    ninja: build stopped: subcommand failed.
    
    



  CMake will not be able to correctly generate this project.
Call Stack (most recent call first):
  CMakeLists.txt:5 (project)


-- Configuring incomplete, errors occurred!
ninja: build stopped: subcommand failed.
```
</details>

<details><summary>C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-rel-CMakeCache.txt.log</summary>

```
# This is the CMakeCache file.
# For build in directory: c:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel
# It was generated by CMake: C:/Program Files/CMake/bin/cmake.exe
# You can edit this file to change values found and used by cmake.
# If you do not want to change any of the values, simply exit the editor.
# If you do want to change a value, simply edit, save, and exit the editor.
# The syntax for the file is as follows:
# KEY:TYPE=VALUE
# KEY is the name of a variable in the cache.
# TYPE is a hint to GUIs for the type of VALUE, DO NOT EDIT TYPE!.
# VALUE is the current value for the KEY.

########################
# EXTERNAL cache entries
########################

//No help, variable specified on the command line.
BOX2D_BENCHMARKS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_COMPILE_WARNING_AS_ERROR:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_DOCS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_PROFILE:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_SAMPLES:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_UNIT_TESTS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_VALIDATE:UNINITIALIZED=OFF

//Global default for the library type used by add_library() when
// no STATIC/SHARED keyword is given: SHARED if true, STATIC otherwise.
// Not defined by CMake itself; commonly exposed as an option()
// by projects.
BUILD_SHARED_LIBS:UNINITIALIZED=ON

//Path to a program.
CMAKE_AR:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/lib.exe

//Choose the type of build, options are: None Debug Release RelWithDebInfo
// MinSizeRel ...
CMAKE_BUILD_TYPE:STRING=Release

CMAKE_CROSSCOMPILING:STRING=OFF

//CXX compiler
CMAKE_CXX_COMPILER:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe

CMAKE_CXX_FLAGS:STRING=' /nologo /DWIN32 /D_WINDOWS /utf-8 /GR /EHsc /MP '

CMAKE_CXX_FLAGS_DEBUG:STRING='/MDd /Z7 /Ob0 /Od /RTC1 '

CMAKE_CXX_FLAGS_RELEASE:STRING='/MD /O2 /Oi /Gy /DNDEBUG /Z7 '

//C compiler
CMAKE_C_COMPILER:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe

CMAKE_C_FLAGS:STRING=' /nologo /DWIN32 /D_WINDOWS /utf-8 /MP '

CMAKE_C_FLAGS_DEBUG:STRING='/MDd /Z7 /Ob0 /Od /RTC1 '

//Flags used by the C compiler during MINSIZEREL builds.
CMAKE_C_FLAGS_MINSIZEREL:STRING=/O1 /Ob1 /DNDEBUG

CMAKE_C_FLAGS_RELEASE:STRING='/MD /O2 /Oi /Gy /DNDEBUG /Z7 '

//Flags used by the C compiler during RELWITHDEBINFO builds.
CMAKE_C_FLAGS_RELWITHDEBINFO:STRING=/Zi /O2 /Ob1 /DNDEBUG

//Libraries linked by default with all C applications.
CMAKE_C_STANDARD_LIBRARIES:STRING=kernel32.lib user32.lib gdi32.lib winspool.lib shell32.lib ole32.lib oleaut32.lib uuid.lib comdlg32.lib advapi32.lib

//Error when cmake_install.cmake encounters absolute INSTALL DESTINATION.
CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION:UNINITIALIZED=ON

//Flags used by the linker during all build types.
CMAKE_EXE_LINKER_FLAGS:STRING=/machine:x64

//Flags used by the linker during DEBUG builds.
CMAKE_EXE_LINKER_FLAGS_DEBUG:STRING=/nologo    /debug /INCREMENTAL

//Flags used by the linker during MINSIZEREL builds.
CMAKE_EXE_LINKER_FLAGS_MINSIZEREL:STRING=/INCREMENTAL:NO

CMAKE_EXE_LINKER_FLAGS_RELEASE:STRING='/nologo /DEBUG /INCREMENTAL:NO /OPT:REF /OPT:ICF  '

//Flags used by the linker during RELWITHDEBINFO builds.
CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO:STRING=/debug /INCREMENTAL

//Enable/Disable output of build database during the build.
CMAKE_EXPORT_BUILD_DATABASE:BOOL=

//Enable/Disable output of compile commands during generation.
CMAKE_EXPORT_COMPILE_COMMANDS:BOOL=

//Disable the export(PACKAGE) command from writing to the user
// package registry when CMP0090 is not set to NEW.
CMAKE_EXPORT_NO_PACKAGE_REGISTRY:UNINITIALIZED=ON

//DEPRECATED: Use CMAKE_FIND_USE_PACKAGE_REGISTRY instead. When
// unset, find_package uses User Package Registry unless disabled.
// Ignored if CMAKE_FIND_USE_PACKAGE_REGISTRY is set.
CMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY:UNINITIALIZED=ON

//DEPRECATED: Use CMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY instead.
// When unset, find_package uses System Package Registry unless
// disabled. Ignored if CMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY
// is set.
CMAKE_FIND_PACKAGE_NO_SYSTEM_PACKAGE_REGISTRY:UNINITIALIZED=ON

//Value Computed by CMake.
...
Skipped 220 lines
...

//Enable the setup of CMAKE_PROGRAM_PATH to vcpkg paths
VCPKG_SETUP_CMAKE_PROGRAM_PATH:BOOL=ON

//No help, variable specified on the command line.
VCPKG_SET_CHARSET_FLAG:UNINITIALIZED=ON

//No help, variable specified on the command line.
VCPKG_TARGET_ARCHITECTURE:UNINITIALIZED=x64

//Vcpkg target triplet (ex. x86-windows)
VCPKG_TARGET_TRIPLET:STRING=x64-windows

//Trace calls to find_package()
VCPKG_TRACE_FIND_PACKAGE:BOOL=OFF

//Use applocal.ps1 instead of vcpkg z-applocal.
VCPKG_USE_LEGACY_APPLOCAL:BOOL=OFF

//Enables messages from the VCPKG toolchain for debugging purposes.
VCPKG_VERBOSE:BOOL=OFF

//(experimental) Automatically copy dependencies into the install
// target directory for executables. Requires CMake 3.14.
X_VCPKG_APPLOCAL_DEPS_INSTALL:BOOL=OFF

//(experimental) Add USES_TERMINAL to VCPKG_APPLOCAL_DEPS to force
// serialization.
X_VCPKG_APPLOCAL_DEPS_SERIALIZED:BOOL=OFF

//The directory which contains the installed libraries for each
// triplet
_VCPKG_INSTALLED_DIR:PATH=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows

//No help, variable specified on the command line.
_VCPKG_ROOT_DIR:UNINITIALIZED=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/

//Value Computed by CMake
box2d_BINARY_DIR:STATIC=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel

//Value Computed by CMake
box2d_IS_TOP_LEVEL:STATIC=ON

//Value Computed by CMake
box2d_SOURCE_DIR:STATIC=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean


########################
# INTERNAL cache entries
########################

//ADVANCED property for variable: CMAKE_AR
CMAKE_AR-ADVANCED:INTERNAL=1
//This is the directory where this CMakeCache.txt was created
CMAKE_CACHEFILE_DIR:INTERNAL=c:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel
//Major version of cmake used to create the current loaded cache
CMAKE_CACHE_MAJOR_VERSION:INTERNAL=4
//Minor version of cmake used to create the current loaded cache
CMAKE_CACHE_MINOR_VERSION:INTERNAL=4
//Patch version of cmake used to create the current loaded cache
CMAKE_CACHE_PATCH_VERSION:INTERNAL=4
//Path to CMake executable.
CMAKE_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cmake.exe
//Path to cpack program executable.
CMAKE_CPACK_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cpack.exe
//Path to ctest program executable.
CMAKE_CTEST_COMMAND:INTERNAL=C:/Program Files/CMake/bin/ctest.exe
//ADVANCED property for variable: CMAKE_CXX_COMPILER
CMAKE_CXX_COMPILER-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_COMPILER
CMAKE_C_COMPILER-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS
CMAKE_C_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_DEBUG
CMAKE_C_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_MINSIZEREL
CMAKE_C_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_RELEASE
CMAKE_C_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_RELWITHDEBINFO
CMAKE_C_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_STANDARD_LIBRARIES
CMAKE_C_STANDARD_LIBRARIES-ADVANCED:INTERNAL=1
//Set initial state for CMake diagnostics; used to persist state
// set by command-line options across invocations.
CMAKE_DIAGNOSTIC_INIT:INTERNAL=CMD_AUTHOR=WARN;CMD_DEPRECATED=WARN;CMD_EXPERIMENTAL=WARN;CMD_INSTALL_ABSOLUTE_DESTINATION=IGNORE;CMD_POLICY=WARN;CMD_UNINITIALIZED=IGNORE;CMD_UNUSED_CLI=WARN
//Path to cache edit program executable.
CMAKE_EDIT_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cmake-gui.exe
//Deprecated.  Use -W[no-]error=deprecated instead.
CMAKE_ERROR_DEPRECATED:INTERNAL=OFF
//Executable file format
CMAKE_EXECUTABLE_FORMAT:INTERNAL=Unknown
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS
CMAKE_EXE_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_DEBUG
CMAKE_EXE_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_MINSIZEREL
CMAKE_EXE_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_RELEASE
CMAKE_EXE_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXPORT_BUILD_DATABASE
CMAKE_EXPORT_BUILD_DATABASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXPORT_COMPILE_COMMANDS
CMAKE_EXPORT_COMPILE_COMMANDS-ADVANCED:INTERNAL=1
//Name of external makefile project generator.
CMAKE_EXTRA_GENERATOR:INTERNAL=
//Name of generator.
CMAKE_GENERATOR:INTERNAL=Ninja
//Generator instance identifier.
CMAKE_GENERATOR_INSTANCE:INTERNAL=
//Name of generator platform.
CMAKE_GENERATOR_PLATFORM:INTERNAL=
//Name of generator toolset.
CMAKE_GENERATOR_TOOLSET:INTERNAL=
//Source directory with the top level CMakeLists.txt file for this
// project
CMAKE_HOME_DIRECTORY:INTERNAL=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean
//ADVANCED property for variable: CMAKE_LINKER
CMAKE_LINKER-ADVANCED:INTERNAL=1
//Name of CMakeLists files to read
CMAKE_LIST_FILE_NAME:INTERNAL=CMakeLists.txt
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS
CMAKE_MODULE_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_DEBUG
CMAKE_MODULE_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_MINSIZEREL
CMAKE_MODULE_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_RELEASE
CMAKE_MODULE_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_MODULE_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MT
CMAKE_MT-ADVANCED:INTERNAL=1
//number of local generators
CMAKE_NUMBER_OF_MAKEFILES:INTERNAL=1
//Platform information initialized
CMAKE_PLATFORM_INFO_INITIALIZED:INTERNAL=1
//ADVANCED property for variable: CMAKE_POLICY_VERSION_MINIMUM
CMAKE_POLICY_VERSION_MINIMUM-ADVANCED:INTERNAL=1
//noop for ranlib
CMAKE_RANLIB:INTERNAL=:
//ADVANCED property for variable: CMAKE_RC_COMPILER
CMAKE_RC_COMPILER-ADVANCED:INTERNAL=1
CMAKE_RC_COMPILER_WORKS:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS
CMAKE_RC_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_DEBUG
CMAKE_RC_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_MINSIZEREL
CMAKE_RC_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_RELEASE
CMAKE_RC_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_RELWITHDEBINFO
CMAKE_RC_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//Path to CMake installation.
CMAKE_ROOT:INTERNAL=C:/Program Files/CMake/share/cmake-4.4
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS
CMAKE_SHARED_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_DEBUG
CMAKE_SHARED_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_MINSIZEREL
CMAKE_SHARED_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_RELEASE
CMAKE_SHARED_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_SHARED_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SKIP_INSTALL_RPATH
CMAKE_SKIP_INSTALL_RPATH-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SKIP_RPATH
CMAKE_SKIP_RPATH-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS
CMAKE_STATIC_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_DEBUG
CMAKE_STATIC_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_MINSIZEREL
CMAKE_STATIC_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_RELEASE
CMAKE_STATIC_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_STATIC_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_TOOLCHAIN_FILE
CMAKE_TOOLCHAIN_FILE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_VERBOSE_MAKEFILE
CMAKE_VERBOSE_MAKEFILE-ADVANCED:INTERNAL=1
//Deprecated.  Use -W[no-]deprecated instead.
CMAKE_WARN_DEPRECATED:INTERNAL=ON
//Install the dependencies listed in your manifest:
//\n    If this is off, you will have to manually install your dependencies.
//\n    See https://github.com/microsoft/vcpkg/tree/master/docs/specifications/manifests.md
// for more info.
//\n
VCPKG_MANIFEST_INSTALL:INTERNAL=OFF
//ADVANCED property for variable: VCPKG_VERBOSE
VCPKG_VERBOSE-ADVANCED:INTERNAL=1
//Making sure VCPKG_MANIFEST_MODE doesn't change
Z_VCPKG_CHECK_MANIFEST_MODE:INTERNAL=OFF
//Vcpkg root directory
Z_VCPKG_ROOT_DIR:INTERNAL=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg

```
</details>

<details><summary>C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-dbg-CMakeCache.txt.log</summary>

```
# This is the CMakeCache file.
# For build in directory: c:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg
# It was generated by CMake: C:/Program Files/CMake/bin/cmake.exe
# You can edit this file to change values found and used by cmake.
# If you do not want to change any of the values, simply exit the editor.
# If you do want to change a value, simply edit, save, and exit the editor.
# The syntax for the file is as follows:
# KEY:TYPE=VALUE
# KEY is the name of a variable in the cache.
# TYPE is a hint to GUIs for the type of VALUE, DO NOT EDIT TYPE!.
# VALUE is the current value for the KEY.

########################
# EXTERNAL cache entries
########################

//No help, variable specified on the command line.
BOX2D_BENCHMARKS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_COMPILE_WARNING_AS_ERROR:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_DOCS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_PROFILE:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_SAMPLES:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_UNIT_TESTS:UNINITIALIZED=OFF

//No help, variable specified on the command line.
BOX2D_VALIDATE:UNINITIALIZED=OFF

//Global default for the library type used by add_library() when
// no STATIC/SHARED keyword is given: SHARED if true, STATIC otherwise.
// Not defined by CMake itself; commonly exposed as an option()
// by projects.
BUILD_SHARED_LIBS:UNINITIALIZED=ON

//Path to a program.
CMAKE_AR:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/lib.exe

//Choose the type of build, options are: None Debug Release RelWithDebInfo
// MinSizeRel ...
CMAKE_BUILD_TYPE:STRING=Debug

CMAKE_CROSSCOMPILING:STRING=OFF

//CXX compiler
CMAKE_CXX_COMPILER:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe

CMAKE_CXX_FLAGS:STRING=' /nologo /DWIN32 /D_WINDOWS /utf-8 /GR /EHsc /MP '

CMAKE_CXX_FLAGS_DEBUG:STRING='/MDd /Z7 /Ob0 /Od /RTC1 '

CMAKE_CXX_FLAGS_RELEASE:STRING='/MD /O2 /Oi /Gy /DNDEBUG /Z7 '

//C compiler
CMAKE_C_COMPILER:FILEPATH=C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe

CMAKE_C_FLAGS:STRING=' /nologo /DWIN32 /D_WINDOWS /utf-8 /MP '

CMAKE_C_FLAGS_DEBUG:STRING='/MDd /Z7 /Ob0 /Od /RTC1 '

//Flags used by the C compiler during MINSIZEREL builds.
CMAKE_C_FLAGS_MINSIZEREL:STRING=/O1 /Ob1 /DNDEBUG

CMAKE_C_FLAGS_RELEASE:STRING='/MD /O2 /Oi /Gy /DNDEBUG /Z7 '

//Flags used by the C compiler during RELWITHDEBINFO builds.
CMAKE_C_FLAGS_RELWITHDEBINFO:STRING=/Zi /O2 /Ob1 /DNDEBUG

//Libraries linked by default with all C applications.
CMAKE_C_STANDARD_LIBRARIES:STRING=kernel32.lib user32.lib gdi32.lib winspool.lib shell32.lib ole32.lib oleaut32.lib uuid.lib comdlg32.lib advapi32.lib

//Error when cmake_install.cmake encounters absolute INSTALL DESTINATION.
CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION:UNINITIALIZED=ON

//Flags used by the linker during all build types.
CMAKE_EXE_LINKER_FLAGS:STRING=/machine:x64

//Flags used by the linker during DEBUG builds.
CMAKE_EXE_LINKER_FLAGS_DEBUG:STRING=/nologo    /debug /INCREMENTAL

//Flags used by the linker during MINSIZEREL builds.
CMAKE_EXE_LINKER_FLAGS_MINSIZEREL:STRING=/INCREMENTAL:NO

CMAKE_EXE_LINKER_FLAGS_RELEASE:STRING='/nologo /DEBUG /INCREMENTAL:NO /OPT:REF /OPT:ICF  '

//Flags used by the linker during RELWITHDEBINFO builds.
CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO:STRING=/debug /INCREMENTAL

//Enable/Disable output of build database during the build.
CMAKE_EXPORT_BUILD_DATABASE:BOOL=

//Enable/Disable output of compile commands during generation.
CMAKE_EXPORT_COMPILE_COMMANDS:BOOL=

//Disable the export(PACKAGE) command from writing to the user
...
Skipped 280 lines
...


########################
# INTERNAL cache entries
########################

//ADVANCED property for variable: CMAKE_AR
CMAKE_AR-ADVANCED:INTERNAL=1
//This is the directory where this CMakeCache.txt was created
CMAKE_CACHEFILE_DIR:INTERNAL=c:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg
//Major version of cmake used to create the current loaded cache
CMAKE_CACHE_MAJOR_VERSION:INTERNAL=4
//Minor version of cmake used to create the current loaded cache
CMAKE_CACHE_MINOR_VERSION:INTERNAL=4
//Patch version of cmake used to create the current loaded cache
CMAKE_CACHE_PATCH_VERSION:INTERNAL=4
//Path to CMake executable.
CMAKE_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cmake.exe
//Path to cpack program executable.
CMAKE_CPACK_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cpack.exe
//Path to ctest program executable.
CMAKE_CTEST_COMMAND:INTERNAL=C:/Program Files/CMake/bin/ctest.exe
//ADVANCED property for variable: CMAKE_CXX_COMPILER
CMAKE_CXX_COMPILER-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_COMPILER
CMAKE_C_COMPILER-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS
CMAKE_C_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_DEBUG
CMAKE_C_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_MINSIZEREL
CMAKE_C_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_RELEASE
CMAKE_C_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_FLAGS_RELWITHDEBINFO
CMAKE_C_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_C_STANDARD_LIBRARIES
CMAKE_C_STANDARD_LIBRARIES-ADVANCED:INTERNAL=1
//Set initial state for CMake diagnostics; used to persist state
// set by command-line options across invocations.
CMAKE_DIAGNOSTIC_INIT:INTERNAL=CMD_AUTHOR=WARN;CMD_DEPRECATED=WARN;CMD_EXPERIMENTAL=WARN;CMD_INSTALL_ABSOLUTE_DESTINATION=IGNORE;CMD_POLICY=WARN;CMD_UNINITIALIZED=IGNORE;CMD_UNUSED_CLI=WARN
//Path to cache edit program executable.
CMAKE_EDIT_COMMAND:INTERNAL=C:/Program Files/CMake/bin/cmake-gui.exe
//Deprecated.  Use -W[no-]error=deprecated instead.
CMAKE_ERROR_DEPRECATED:INTERNAL=OFF
//Executable file format
CMAKE_EXECUTABLE_FORMAT:INTERNAL=Unknown
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS
CMAKE_EXE_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_DEBUG
CMAKE_EXE_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_MINSIZEREL
CMAKE_EXE_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_RELEASE
CMAKE_EXE_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXPORT_BUILD_DATABASE
CMAKE_EXPORT_BUILD_DATABASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_EXPORT_COMPILE_COMMANDS
CMAKE_EXPORT_COMPILE_COMMANDS-ADVANCED:INTERNAL=1
//Name of external makefile project generator.
CMAKE_EXTRA_GENERATOR:INTERNAL=
//Name of generator.
CMAKE_GENERATOR:INTERNAL=Ninja
//Generator instance identifier.
CMAKE_GENERATOR_INSTANCE:INTERNAL=
//Name of generator platform.
CMAKE_GENERATOR_PLATFORM:INTERNAL=
//Name of generator toolset.
CMAKE_GENERATOR_TOOLSET:INTERNAL=
//Source directory with the top level CMakeLists.txt file for this
// project
CMAKE_HOME_DIRECTORY:INTERNAL=C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/src/v3.1.1-9e4ca3be47.clean
//ADVANCED property for variable: CMAKE_LINKER
CMAKE_LINKER-ADVANCED:INTERNAL=1
//Name of CMakeLists files to read
CMAKE_LIST_FILE_NAME:INTERNAL=CMakeLists.txt
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS
CMAKE_MODULE_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_DEBUG
CMAKE_MODULE_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_MINSIZEREL
CMAKE_MODULE_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_RELEASE
CMAKE_MODULE_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MODULE_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_MODULE_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_MT
CMAKE_MT-ADVANCED:INTERNAL=1
//number of local generators
CMAKE_NUMBER_OF_MAKEFILES:INTERNAL=1
//Platform information initialized
CMAKE_PLATFORM_INFO_INITIALIZED:INTERNAL=1
//ADVANCED property for variable: CMAKE_POLICY_VERSION_MINIMUM
CMAKE_POLICY_VERSION_MINIMUM-ADVANCED:INTERNAL=1
//noop for ranlib
CMAKE_RANLIB:INTERNAL=:
//ADVANCED property for variable: CMAKE_RC_COMPILER
CMAKE_RC_COMPILER-ADVANCED:INTERNAL=1
CMAKE_RC_COMPILER_WORKS:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS
CMAKE_RC_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_DEBUG
CMAKE_RC_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_MINSIZEREL
CMAKE_RC_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_RELEASE
CMAKE_RC_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_RC_FLAGS_RELWITHDEBINFO
CMAKE_RC_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//Path to CMake installation.
CMAKE_ROOT:INTERNAL=C:/Program Files/CMake/share/cmake-4.4
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS
CMAKE_SHARED_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_DEBUG
CMAKE_SHARED_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_MINSIZEREL
CMAKE_SHARED_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_RELEASE
CMAKE_SHARED_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SHARED_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_SHARED_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SKIP_INSTALL_RPATH
CMAKE_SKIP_INSTALL_RPATH-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_SKIP_RPATH
CMAKE_SKIP_RPATH-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS
CMAKE_STATIC_LINKER_FLAGS-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_DEBUG
CMAKE_STATIC_LINKER_FLAGS_DEBUG-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_MINSIZEREL
CMAKE_STATIC_LINKER_FLAGS_MINSIZEREL-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_RELEASE
CMAKE_STATIC_LINKER_FLAGS_RELEASE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_STATIC_LINKER_FLAGS_RELWITHDEBINFO
CMAKE_STATIC_LINKER_FLAGS_RELWITHDEBINFO-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_TOOLCHAIN_FILE
CMAKE_TOOLCHAIN_FILE-ADVANCED:INTERNAL=1
//ADVANCED property for variable: CMAKE_VERBOSE_MAKEFILE
CMAKE_VERBOSE_MAKEFILE-ADVANCED:INTERNAL=1
//Deprecated.  Use -W[no-]deprecated instead.
CMAKE_WARN_DEPRECATED:INTERNAL=ON
//Install the dependencies listed in your manifest:
//\n    If this is off, you will have to manually install your dependencies.
//\n    See https://github.com/microsoft/vcpkg/tree/master/docs/specifications/manifests.md
// for more info.
//\n
VCPKG_MANIFEST_INSTALL:INTERNAL=OFF
//ADVANCED property for variable: VCPKG_VERBOSE
VCPKG_VERBOSE-ADVANCED:INTERNAL=1
//Making sure VCPKG_MANIFEST_MODE doesn't change
Z_VCPKG_CHECK_MANIFEST_MODE:INTERNAL=OFF
//Vcpkg root directory
Z_VCPKG_ROOT_DIR:INTERNAL=C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg

```
</details>

<details><summary>C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-rel-CMakeConfigureLog.yaml.log</summary>

```

---
events:
  -
    kind: "message-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineSystem.cmake:218 (message)"
      - "CMakeLists.txt:5 (project)"
    message: |
      The system is: Windows - 10.0.26200 - AMD64
  -
    kind: "find-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineCompiler.cmake:63 (find_program)"
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineCCompiler.cmake:64 (_cmake_find_compiler)"
      - "CMakeLists.txt:5 (project)"
    mode: "program"
    variable: "CMAKE_C_COMPILER"
    description: "C compiler"
    settings:
      SearchFramework: "LAST"
      SearchAppBundle: "LAST"
      CMAKE_FIND_USE_CMAKE_PATH: false
      CMAKE_FIND_USE_CMAKE_ENVIRONMENT_PATH: false
      CMAKE_FIND_USE_SYSTEM_ENVIRONMENT_PATH: true
      CMAKE_FIND_USE_CMAKE_SYSTEM_PATH: false
      CMAKE_FIND_USE_INSTALL_PREFIX: true
    names:
      - "cc"
      - "gcc"
      - "cl"
      - "bcc"
      - "xlc"
      - "icx"
      - "clang"
    candidate_directories:
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/VC/vcpackages/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/TestWindow/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/TeamFoundation/Team Explorer/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/MSBuild/Current/Bin/Roslyn/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files (x86)/Microsoft SDKs/Windows/v10.0A/bin/NETFX 4.8 Tools/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/Team Tools/DiagnosticsHub/Collector/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/Extensions/Microsoft/CodeCoverage.Console/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files (x86)/Windows Kits/10/bin/10.0.26100.0/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files (x86)/Windows Kits/10/bin/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/Program Files/Microsoft Visual Studio/18/Community/MSBuild/Current/Bin/amd64/"
...
Skipped 3722 lines
...
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeTestCCompiler.cmake:26 (CMAKE_DETERMINE_COMPILER_ABI)"
      - "CMakeLists.txt:5 (project)"
    checks:
      - "Detecting C compiler ABI info"
    directories:
      source: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-idc09u"
      binary: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-idc09u"
    cmakeVariables:
      CMAKE_CXX_STDLIB_MODULES_JSON: ""
      CMAKE_C_FLAGS: " /nologo /DWIN32 /D_WINDOWS /utf-8 /MP "
      CMAKE_C_FLAGS_DEBUG: "/MDd /Z7 /Ob0 /Od /RTC1 "
      CMAKE_EXE_LINKER_FLAGS: "/machine:x64"
      CMAKE_MSVC_DEBUG_INFORMATION_FORMAT: ""
      CMAKE_MSVC_RUNTIME_LIBRARY: "MultiThreaded$<$<CONFIG:Debug>:Debug>$<$<STREQUAL:dynamic,dynamic>:DLL>"
      VCPKG_CHAINLOAD_TOOLCHAIN_FILE: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake"
      VCPKG_CRT_LINKAGE: "dynamic"
      VCPKG_CXX_FLAGS: ""
      VCPKG_CXX_FLAGS_DEBUG: ""
      VCPKG_CXX_FLAGS_RELEASE: ""
      VCPKG_C_FLAGS: ""
      VCPKG_C_FLAGS_DEBUG: ""
      VCPKG_C_FLAGS_RELEASE: ""
      VCPKG_INSTALLED_DIR: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows"
      VCPKG_LINKER_FLAGS: ""
      VCPKG_LINKER_FLAGS_DEBUG: ""
      VCPKG_LINKER_FLAGS_RELEASE: ""
      VCPKG_PLATFORM_TOOLSET: "v145"
      VCPKG_PREFER_SYSTEM_LIBS: "OFF"
      VCPKG_SET_CHARSET_FLAG: "ON"
      VCPKG_TARGET_ARCHITECTURE: "x64"
      VCPKG_TARGET_TRIPLET: "x64-windows"
      Z_VCPKG_ROOT_DIR: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg"
    buildResult:
      variable: "CMAKE_C_ABI_COMPILED"
      cached: false
      stdout: |
        Change Dir: 'C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-idc09u'
        
        Run Build Command(s): "C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe" -v cmTC_d5ae3
        [1/2] "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_d5ae3.dir\\CMakeCCompilerABI.c.obj /FdCMakeFiles\\cmTC_d5ae3.dir\\ /FS -c "C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c"
        FAILED: [code=1] CMakeFiles/cmTC_d5ae3.dir/CMakeCCompilerABI.c.obj 
        "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_d5ae3.dir\\CMakeCCompilerABI.c.obj /FdCMakeFiles\\cmTC_d5ae3.dir\\ /FS -c "C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c"
        C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c : fatal error C1083: No se puede abrir el archivo generado por el compilador: '': Invalid argument
        ninja: build stopped: subcommand failed.
        
      exitCode: 1
  -
    kind: "try_compile-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeTestCCompiler.cmake:56 (try_compile)"
      - "CMakeLists.txt:5 (project)"
    checks:
      - "Check for working C compiler: C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe"
    directories:
      source: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27"
      binary: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27"
    cmakeVariables:
      CMAKE_CXX_STDLIB_MODULES_JSON: ""
      CMAKE_C_FLAGS: " /nologo /DWIN32 /D_WINDOWS /utf-8 /MP "
      CMAKE_C_FLAGS_DEBUG: "/MDd /Z7 /Ob0 /Od /RTC1 "
      CMAKE_EXE_LINKER_FLAGS: "/machine:x64"
      CMAKE_MSVC_DEBUG_INFORMATION_FORMAT: ""
      CMAKE_MSVC_RUNTIME_LIBRARY: "MultiThreaded$<$<CONFIG:Debug>:Debug>$<$<STREQUAL:dynamic,dynamic>:DLL>"
      VCPKG_CHAINLOAD_TOOLCHAIN_FILE: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake"
      VCPKG_CRT_LINKAGE: "dynamic"
      VCPKG_CXX_FLAGS: ""
      VCPKG_CXX_FLAGS_DEBUG: ""
      VCPKG_CXX_FLAGS_RELEASE: ""
      VCPKG_C_FLAGS: ""
      VCPKG_C_FLAGS_DEBUG: ""
      VCPKG_C_FLAGS_RELEASE: ""
      VCPKG_INSTALLED_DIR: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows"
      VCPKG_LINKER_FLAGS: ""
      VCPKG_LINKER_FLAGS_DEBUG: ""
      VCPKG_LINKER_FLAGS_RELEASE: ""
      VCPKG_PLATFORM_TOOLSET: "v145"
      VCPKG_PREFER_SYSTEM_LIBS: "OFF"
      VCPKG_SET_CHARSET_FLAG: "ON"
      VCPKG_TARGET_ARCHITECTURE: "x64"
      VCPKG_TARGET_TRIPLET: "x64-windows"
      Z_VCPKG_ROOT_DIR: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg"
    buildResult:
      variable: "CMAKE_C_COMPILER_WORKS"
      cached: false
      stdout: |
        Change Dir: 'C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-rel/CMakeFiles/CMakeScratch/TryCompile-5cmz27'
        
        Run Build Command(s): "C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe" -v cmTC_2a00d
        [1/2] "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_2a00d.dir\\testCCompiler.c.obj /FdCMakeFiles\\cmTC_2a00d.dir\\ /FS -c C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-rel\\CMakeFiles\\CMakeScratch\\TryCompile-5cmz27\\testCCompiler.c
        FAILED: [code=1] CMakeFiles/cmTC_2a00d.dir/testCCompiler.c.obj 
        "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_2a00d.dir\\testCCompiler.c.obj /FdCMakeFiles\\cmTC_2a00d.dir\\ /FS -c C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-rel\\CMakeFiles\\CMakeScratch\\TryCompile-5cmz27\\testCCompiler.c
        C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-rel\\CMakeFiles\\CMakeScratch\\TryCompile-5cmz27\\testCCompiler.c : fatal error C1083: No se puede abrir el archivo generado por el compilador: '': Invalid argument
        ninja: build stopped: subcommand failed.
        
      exitCode: 1
...
```
</details>

<details><summary>C:\Users\jonat\OneDrive\Documentos\GitHub\Desarollo-de-videojuegos\Pro\Pro\Animaciones\CITM_DSVJ_2026-27-L10_Animations_Parameters\vcpkg_installed\x64-windows\vcpkg\blds\box2d\config-x64-windows-dbg-CMakeConfigureLog.yaml.log</summary>

```

---
events:
  -
    kind: "message-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineSystem.cmake:218 (message)"
      - "CMakeLists.txt:5 (project)"
    message: |
      The system is: Windows - 10.0.26200 - AMD64
  -
    kind: "find-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineCompiler.cmake:63 (find_program)"
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeDetermineCCompiler.cmake:64 (_cmake_find_compiler)"
      - "CMakeLists.txt:5 (project)"
    mode: "program"
    variable: "CMAKE_C_COMPILER"
    description: "C compiler"
    settings:
      SearchFramework: "LAST"
      SearchAppBundle: "LAST"
      CMAKE_FIND_USE_CMAKE_PATH: false
      CMAKE_FIND_USE_CMAKE_ENVIRONMENT_PATH: false
      CMAKE_FIND_USE_SYSTEM_ENVIRONMENT_PATH: true
      CMAKE_FIND_USE_CMAKE_SYSTEM_PATH: false
      CMAKE_FIND_USE_INSTALL_PREFIX: true
    names:
      - "cc"
      - "gcc"
      - "cl"
      - "bcc"
      - "xlc"
      - "icx"
      - "clang"
    candidate_directories:
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/VC/vcpackages/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/TestWindow/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/TeamFoundation/Team Explorer/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/MSBuild/Current/Bin/Roslyn/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files (x86)/Microsoft SDKs/Windows/v10.0A/bin/NETFX 4.8 Tools/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/Team Tools/DiagnosticsHub/Collector/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/Extensions/Microsoft/CodeCoverage.Console/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files (x86)/Windows Kits/10/bin/10.0.26100.0/x64/"
      - "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/x64-windows/debug/Program Files (x86)/Windows Kits/10/bin/x64/"
...
Skipped 3724 lines
...
      - "CMakeLists.txt:5 (project)"
    checks:
      - "Detecting C compiler ABI info"
    directories:
      source: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-onfgt5"
      binary: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-onfgt5"
    cmakeVariables:
      CMAKE_CXX_STDLIB_MODULES_JSON: ""
      CMAKE_C_FLAGS: " /nologo /DWIN32 /D_WINDOWS /utf-8 /MP "
      CMAKE_C_FLAGS_DEBUG: "/MDd /Z7 /Ob0 /Od /RTC1 "
      CMAKE_EXE_LINKER_FLAGS: "/machine:x64"
      CMAKE_MSVC_DEBUG_INFORMATION_FORMAT: ""
      CMAKE_MSVC_RUNTIME_LIBRARY: "MultiThreaded$<$<CONFIG:Debug>:Debug>$<$<STREQUAL:dynamic,dynamic>:DLL>"
      VCPKG_CHAINLOAD_TOOLCHAIN_FILE: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake"
      VCPKG_CRT_LINKAGE: "dynamic"
      VCPKG_CXX_FLAGS: ""
      VCPKG_CXX_FLAGS_DEBUG: ""
      VCPKG_CXX_FLAGS_RELEASE: ""
      VCPKG_C_FLAGS: ""
      VCPKG_C_FLAGS_DEBUG: ""
      VCPKG_C_FLAGS_RELEASE: ""
      VCPKG_INSTALLED_DIR: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows"
      VCPKG_LINKER_FLAGS: ""
      VCPKG_LINKER_FLAGS_DEBUG: ""
      VCPKG_LINKER_FLAGS_RELEASE: ""
      VCPKG_PLATFORM_TOOLSET: "v145"
      VCPKG_PREFER_SYSTEM_LIBS: "OFF"
      VCPKG_SET_CHARSET_FLAG: "ON"
      VCPKG_TARGET_ARCHITECTURE: "x64"
      VCPKG_TARGET_TRIPLET: "x64-windows"
      Z_VCPKG_ROOT_DIR: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg"
    buildResult:
      variable: "CMAKE_C_ABI_COMPILED"
      cached: false
      stdout: |
        Change Dir: 'C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-onfgt5'
        
        Run Build Command(s): "C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe" -v cmTC_32863
        [1/2] "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_32863.dir\\CMakeCCompilerABI.c.obj /FdCMakeFiles\\cmTC_32863.dir\\ /FS -c "C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c"
        FAILED: [code=1] CMakeFiles/cmTC_32863.dir/CMakeCCompilerABI.c.obj 
        "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_32863.dir\\CMakeCCompilerABI.c.obj /FdCMakeFiles\\cmTC_32863.dir\\ /FS -c "C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c"
        C:\\Program Files\\CMake\\share\\cmake-4.4\\Modules\\CMakeCCompilerABI.c : fatal error C1083: No se puede abrir el archivo generado por el compilador: '': Invalid argument
        ninja: build stopped: subcommand failed.
        
      exitCode: 1
  -
    kind: "try_compile-v1"
    backtrace:
      - "C:/Program Files/CMake/share/cmake-4.4/Modules/CMakeTestCCompiler.cmake:56 (try_compile)"
      - "CMakeLists.txt:5 (project)"
    checks:
      - "Check for working C compiler: C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe"
    directories:
      source: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-81a0wj"
      binary: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-81a0wj"
    cmakeVariables:
      CMAKE_CXX_STDLIB_MODULES_JSON: ""
      CMAKE_C_FLAGS: " /nologo /DWIN32 /D_WINDOWS /utf-8 /MP "
      CMAKE_C_FLAGS_DEBUG: "/MDd /Z7 /Ob0 /Od /RTC1 "
      CMAKE_EXE_LINKER_FLAGS: "/machine:x64"
      CMAKE_MSVC_DEBUG_INFORMATION_FORMAT: ""
      CMAKE_MSVC_RUNTIME_LIBRARY: "MultiThreaded$<$<CONFIG:Debug>:Debug>$<$<STREQUAL:dynamic,dynamic>:DLL>"
      VCPKG_CHAINLOAD_TOOLCHAIN_FILE: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg/scripts/toolchains/windows.cmake"
      VCPKG_CRT_LINKAGE: "dynamic"
      VCPKG_CXX_FLAGS: ""
      VCPKG_CXX_FLAGS_DEBUG: ""
      VCPKG_CXX_FLAGS_RELEASE: ""
      VCPKG_C_FLAGS: ""
      VCPKG_C_FLAGS_DEBUG: ""
      VCPKG_C_FLAGS_RELEASE: ""
      VCPKG_INSTALLED_DIR: "C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows"
      VCPKG_LINKER_FLAGS: ""
      VCPKG_LINKER_FLAGS_DEBUG: ""
      VCPKG_LINKER_FLAGS_RELEASE: ""
      VCPKG_PLATFORM_TOOLSET: "v145"
      VCPKG_PREFER_SYSTEM_LIBS: "OFF"
      VCPKG_SET_CHARSET_FLAG: "ON"
      VCPKG_TARGET_ARCHITECTURE: "x64"
      VCPKG_TARGET_TRIPLET: "x64-windows"
      Z_VCPKG_ROOT_DIR: "C:/Program Files/Microsoft Visual Studio/18/Community/VC/vcpkg"
    buildResult:
      variable: "CMAKE_C_COMPILER_WORKS"
      cached: false
      stdout: |
        Change Dir: 'C:/Users/jonat/OneDrive/Documentos/GitHub/Desarollo-de-videojuegos/Pro/Pro/Animaciones/CITM_DSVJ_2026-27-L10_Animations_Parameters/vcpkg_installed/x64-windows/vcpkg/blds/box2d/x64-windows-dbg/CMakeFiles/CMakeScratch/TryCompile-81a0wj'
        
        Run Build Command(s): "C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe" -v cmTC_f1889
        [1/2] "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_f1889.dir\\testCCompiler.c.obj /FdCMakeFiles\\cmTC_f1889.dir\\ /FS -c C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-dbg\\CMakeFiles\\CMakeScratch\\TryCompile-81a0wj\\testCCompiler.c
        FAILED: [code=1] CMakeFiles/cmTC_f1889.dir/testCCompiler.c.obj 
        "C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe"  /nologo -D_MBCS  /nologo /DWIN32 /D_WINDOWS /utf-8 /MP   /MDd /Z7 /Ob0 /Od /RTC1  -MDd /showIncludes /FoCMakeFiles\\cmTC_f1889.dir\\testCCompiler.c.obj /FdCMakeFiles\\cmTC_f1889.dir\\ /FS -c C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-dbg\\CMakeFiles\\CMakeScratch\\TryCompile-81a0wj\\testCCompiler.c
        C:\\Users\\jonat\\OneDrive\\Documentos\\GitHub\\Desarollo-de-videojuegos\\Pro\\Pro\\Animaciones\\CITM_DSVJ_2026-27-L10_Animations_Parameters\\vcpkg_installed\\x64-windows\\vcpkg\\blds\\box2d\\x64-windows-dbg\\CMakeFiles\\CMakeScratch\\TryCompile-81a0wj\\testCCompiler.c : fatal error C1083: No se puede abrir el archivo generado por el compilador: '': Invalid argument
        ninja: build stopped: subcommand failed.
        
      exitCode: 1
...
```
</details>

**Additional context**

<details><summary>vcpkg.json</summary>

```
{
  "builtin-baseline": "9e593bb18ea69cc5095e012465dcd675a822ed0d",
  "dependencies": [
    "box2d",
    "libjpeg-turbo",
    "libpng",
    "pugixml",
    "sdl3",
    {
      "name": "sdl3-image",
      "features": [
        "jpeg",
        "png"
      ]
    }
  ],
  "overrides": [
    {
      "name": "sdl3",
      "version": "3.4.12"
    },
    {
      "name": "sdl3-image",
      "version": "3.4.4"
    }
  ]
}

```
</details>
