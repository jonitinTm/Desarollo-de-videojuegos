#include "Player.h"
#include "Engine.h"
#include "Textures.h"
#include "Input.h"
#include "Render.h"
#include "Log.h"
#include "Physics.h"
#include "Audio.h"
#include "Map.h"

Player::Player() : Entity(EntityType::PLAYER)
{
	name = "Player";
}

Player::~Player()
{}



//N
bool Player::Awake()
{
	// L04: TODO 2: Initialize the player's position
	position = Vector2D(150.0f, 1625.0f);
	spawnPoint = position;

	return true;
}

bool Player::Start()
{
	// L10: TODO 5: Read texture, frame size and tuning from config.xml
	// instead of hardcoding them. GetSize() is not the fix for texW/texH --
	// the real texture (a spritesheet) would return the whole sheet's size,
	// not one frame's.
	// L04: TODO 2: Load the player texture
	texture = Engine::GetInstance().textures->Load(parameters.child("texture").attribute("path").as_string());

	texW = parameters.child("frame").attribute("width").as_int();
	texH = parameters.child("frame").attribute("height").as_int();


	// L10: TODO 5: Load this entity's animations from a TSX and set the current animation to "idle".
	// ...
	
	anims.LoadFromTSX(parameters.child("animations").attribute("tsx").as_string(), { {0, "idle"}, {16, "run"}, {40, "roll"}, {48, "hit"}, {56, "death"} });
		anims.SetCurrent("idle");


	// N Añadir efectos de audio


	pickCoinFxId = Engine::GetInstance().audio->LoadFx("Assets/Audio/Fx/coin-collision-sound-342335.wav");

	hurtFxId = Engine::GetInstance().audio->LoadFx("Assets/Audio/Fx/off.wav");


	//--------------->
	// L08: TODO 5: Add physics to the player - create the physics body: a CAPSULE (CreateCapsule) with fixed rotation, so the player does not roll
	pbody = Engine::GetInstance().physics->CreateCircle((int)position.getX() + texW / 2, (int)position.getY() + texH / 2, texW / 2, bodyType::DYNAMIC);

	// L08: TODO 6: Assign player class (using "this") to the listener of the pbody. This makes the Physics module to call the OnCollision method
	pbody->listener = this;

	// L08: TODO 7: Assign collider type
	pbody->ctype = ColliderType::PLAYER;

	return true;
}

bool Player::Update(float dt)
{
	// L08: TODO 5: Add physics to the player - updated player position using physics

	velocity = Engine::GetInstance().physics->GetLinearVelocity(pbody);
	velocity = { 0, velocity.y }; // Reset horizontal velocity by default, this way the player stops when no key is pressed


	//N Creamos variable de animacion jugador
	std::string anim = "idle";


	// L10: TODO 7: Default to the "idle" animation; a key below overrides it
	// ..

	// Move left/right

	// N mecanica de rodamiento
	if (!rolling)
	{


		if (Engine::GetInstance().input->GetKey(SDL_SCANCODE_A) == KEY_REPEAT) {
			velocity.x = -speed;
			// L10: TODO 7: Switch to the "move" animation
			// ..
			anim = "run";
			facing = -1;
		}
		if (Engine::GetInstance().input->GetKey(SDL_SCANCODE_D) == KEY_REPEAT) {
			velocity.x = speed;
			// L10: TODO 7: Switch to the "move" animation
			// ..
			anim = "run";
			facing = 1;
		}

		if (Engine::GetInstance().input->GetKey(SDL_SCANCODE_W) == KEY_REPEAT) {
			velocity.y = -speed;
			// L10: TODO 7: Switch to the "move" animation
			// ..

		}

		if (Engine::GetInstance().input->GetKey(SDL_SCANCODE_SPACE) == KEY_REPEAT) {

			rolling = true;
			rollTimer = rollDuration;
		}

	}

	if (rolling)
	{

		velocity.x = rollSpeed * facing;
		anim = "roll";

		rollTimer -= dt;

		if (rollTimer <= 0)
		{
			rolling = false;
		}



	}




	//  N  Mecanicas de vidas


	if (invulnerable)
	{
		invulTimer -= dt;

		if (invulTimer <= 0) invulnerable = false;

	}

	if (hitTimer > 0) hitTimer -= dt;
	if (hitTimer > 0) anim = "hit";





















	anims.SetCurrent(anim);
	//N actualizacion por segundo
	anims.Update(dt);

	// Apply velocity via helper
	Engine::GetInstance().physics->SetLinearVelocity(pbody, velocity);

	int x, y;
	pbody->GetPosition(x, y);
	position.setX((float)x);
	position.setY((float)y);

	// L10: TODO 8: Camera follow
	// ..

	Vector2D mapSize =	Engine::GetInstance().map->GetMapSizeInPixels();
	float camW = Engine::GetInstance().render->camera.w;
	float limitLeft = camW / 4;
	float limitRight = mapSize.getX() - camW * 3.0f / 4.0f;

	if (position.getX() > limitLeft || position.getX() < limitRight)
	{
		Engine::GetInstance().render->camera.x =   camW/4.0f - position.getX();

		Engine::GetInstance().render->camera.y = camW / 4.0f - position.getY();
	}



	// L10: TODO 6: Advance the animation frame
	// ..
	anims.Update(dt);


	return true;
}


















bool Player::Draw()
{
	// L08: TODO 5: Add physics to the player - updated player position using physics
	// L04: TODO 4: Render the player texture at its current position

	// L10: TODO 6: Draw the current animation frame instead of the whole spritesheet
	// ..
	SDL_Rect currentFrame = anims.GetCurrentFrame();





	Engine::GetInstance().render->DrawTexture(texture, (int)position.getX() - texW / 2, (int)position.getY() - texH / 2, &currentFrame);

	return true;
}

bool Player::CleanUp()
{
	LOG("Cleanup player");
	// Release the physics body first, then the texture
	if (pbody != nullptr)
	{
		pbody->listener = nullptr;
		Engine::GetInstance().physics->DeletePhysBody(pbody);
		pbody = nullptr;
	}

	if (texture != nullptr)
	{
		Engine::GetInstance().textures->UnLoad(texture);
		texture = nullptr;
	}
	return true;
}



// N Crear la funcion de la muerte------->


void Player:: TakeDamage()
{

	if (invulnerable) return;// si esta invulnerable mo pasa nada

	lives--; //Quitamos una vida
	invulnerable = true; // tiempo que es invulnerable

	invulTimer = invulDuration;

	hitTimer = 0.4f; //Animacion de hit


	Engine::GetInstance().audio->PlayFx(hurtFxId);
	LOG("Jugador herido, tiene: %d", lives);
}







// L08: TODO 6: Define OnCollision function for the player.
void Player::OnCollision(PhysBody* physA, PhysBody* physB)
{
	// Handle collision with other physics bodies
	// For example, if the player collides with an item, you can implement logic here
	switch (physB->ctype)
	{
	case ColliderType::PLATFORM:
		LOG("Collision PLATFORM");
		break;
	case ColliderType::ITEM:
		
		//Play the coin pickup sound effect 
		Engine::GetInstance().audio->PlayFx(pickCoinFxId);

		// Destroy the item. 
		physB->listener->Destroy(); 

		LOG("Collision ITEM");

		break;


		//N La etiqueta llama, y todo el mundo obedece
		case ColliderType:: DEATH:

			TakeDamage();

		break;


	case ColliderType::UNKNOWN:
		LOG("Collision UNKNOWN");
		break;
	default:
		break;
	}
}
